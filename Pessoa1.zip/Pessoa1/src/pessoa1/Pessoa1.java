package pessoa1;

public class Pessoa1 {

    
    private String nome;
    private float peso, altura, imc, calculo;
    private int idade;
    
    
    public Pessoa1(){   //parametro vazio
        
    }

    public Pessoa1(String nome, float peso, float altura, int idade) {
        this.nome = nome;
        this.peso = peso;
        this.altura = altura;
        this.idade = idade;
    }
    
    
   

    @Override
    public String toString() {
        return "Pessoa1{" + "nome=" + nome + ", peso=" + peso + ", altura=" + altura + ", imc=" + imc + ", calculo=" + calculo + ", idade=" + idade + '}';
        
        
    }
    
    
    public float imc(){
        
       imc = peso /(altura*altura);
        return imc;
    }

    public static void main(String[] args) {
      
   Pessoa1 objPessoa1 = new Pessoa1("Jhe", 45f, 1.65f, 19);
   
        System.out.println(objPessoa1.imc());
        
        System.out.println(objPessoa1.toString());
    
 
    }
}
